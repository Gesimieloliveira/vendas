<h1>Your Username : {{$name}}</h1>
<h1>Your Password : {{$password}}</h1>